package com.example.first_application;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class secintent extends AppCompatActivity {

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        TextView WelcomeText, luckyNumberText;
        ImageButton share_btn;
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_secintent);

        WelcomeText = findViewById(R.id.textView);
        luckyNumberText = findViewById(R.id.textView3);
        share_btn = findViewById(R.id.imageButton);

        Intent i = getIntent();
        String userName = i.getStringExtra("name");
        int random_num = generateRandomNumber();
        luckyNumberText.setText("" + random_num);

        share_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareData(userName, random_num);
            }
        });
    }

    public int generateRandomNumber() {
        Random random = new Random();
        int upper_limit = 100;
        return random.nextInt(upper_limit);
    }

    public void shareData(String userName, int random_num) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, userName + " got lucky number");
        i.putExtra(Intent.EXTRA_TEXT, "Your lucky number is " + random_num);
        startActivity(Intent.createChooser(i, "Choose a platform"));
    }
}
